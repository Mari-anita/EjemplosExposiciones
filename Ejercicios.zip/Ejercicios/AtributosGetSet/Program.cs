﻿// See https://aka.ms/new-console-template for more information
using System;

namespace AtributosGetSet
{

    public class Persona
    {
        //Atributo privado
        //Al ser privados no se puede acceder directamente desde fuera de la clase Persona
        private string nombre;

        //Propiedad pública para acceder y modificar el atributo privado
        public string Nombre
        {
            get
            {
                return nombre;
            }
            set
            {
                nombre = value;
            }
        }

        //Atributo privado
        private int edad;

        //Propiedad pública para acceder y modificar el atributo privado
        public int Edad
        {
            get
            {
                return edad;
            }
            set
            {
                if (value >= 0)
                {
                    edad = value;
                }
                else
                {
                    Console.WriteLine("La edad no puede ser negativa.");
                }
            }
        }
    }

    public class Program
    {
        //En el método Main, se crean instancias de la clase Persona
        //y se utilizan las propiedades Nombre y Edad para acceder y modificar los atributos.
        static void Main()
        {
            //Crea una instancia de la clase Persona
            Persona persona = new Persona();

            //Usa las propiedades para establecer valores
            persona.Nombre = "Camila";
            persona.Edad = 22;

            //Usa las propiedades para obtener valores
            Console.WriteLine($"Nombre: {persona.Nombre}");
            Console.WriteLine($"Edad: {persona.Edad}");

            //Intenta establecer una edad negativa
            persona.Edad = -5; //Salida: "La edad no puede ser negativa."
            Console.WriteLine($"Edad después de intento inválido: {persona.Edad}");
        }
    }
}

