﻿using System;

namespace AsyncAwait
{
    public class program
    {
       static async Task Main(string[] args) //async: Indica que el método puede contener operaciones asincrónicas.
                                             //Task: El método devuelve un Task, lo que permite el uso de await dentro del método.
        {
            var tarea = new Task(delegate { Prueba(); }); //Crea una nueva instancia de Task
                                                          //utilizando un delegado que llama al método Prueba.
                                                          //por eso en consola aprece primero "Tarea" y despues "Hilo principal"

            tarea.Start();//Inicia la tarea (Task), lo que hace que el método Prueba se ejecute de manera asincrónica.

            Console.WriteLine("Hilo principal");
        }

        private static void Prueba()
        {
            Console.WriteLine("Tarea");
        }
    }
}
