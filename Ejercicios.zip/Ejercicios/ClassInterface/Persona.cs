﻿// See https://aka.ms/new-console-template for more information
using ClassInterface;
using System;

namespace ClassInterface
{
    public class Persona : IPersona //Declara la clase pública llamada Persona que implementa la interfaz IPersona
    {
        public string Nombre { get; set; } //Propiedad pública Nombre con getters y setters

        public Persona(string nombre) //Constructor que inicializa la propiedad Nombre
        {
            Nombre = nombre;
        }

        //Implementación de los método Saludar y Despedirse que imprime un mensaje en la consola
        public void Saludar()
        {
            Console.WriteLine($"Hola, mi nombre es {Nombre}.");
        }

        public void Despedirse()
        {
            Console.WriteLine($"Adiós, {Nombre} se despide.");
        }
    }

    public class Program //Define la clase Program que contiene el punto de entrada de la aplicación (metodo main)
    {
        static void Main(string[] args)
        {
            IPersona persona = new Persona("Juan"); //Se crea una nueva instancia de Persona con el nombre "Juan"
                                                    //y se asigna a la variable persona de tipo IPersona

            //Llama los métodos Saludar y Despedirse de la instancia persona
            persona.Saludar();
            persona.Despedirse();

            Console.ReadLine();  //Mantiene la consola abierta
                                 //esperando que el usuario de enter para cerrarla
        }
    }
}
