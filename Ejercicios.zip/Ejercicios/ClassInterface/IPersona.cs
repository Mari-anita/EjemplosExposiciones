﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassInterface
{
    public interface IPersona //Declara la interfaz pública llamada IPersona
    {
        //Declara los método Saludar y Despedirse que no devuelven ningún valor.
        void Saludar();
        void Despedirse();
    }
}
