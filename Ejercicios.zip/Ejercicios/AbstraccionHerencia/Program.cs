﻿// See https://aka.ms/new-console-template for more information
using System;

namespace AbstraccionHerencia
{
    //Clase abstracta que define la interfaz común para los animales
    abstract class Animal
    {
        //Propiedad Nombre común para todos los animales
        public string Nombre { get; set; }

        //Constructor para inicializar el nombre
        public Animal(string nombre)
        {
            Nombre = nombre;
        }

        //Método abstracto que debe ser implementado por las clases derivadas
        public abstract void HacerSonido();

        //Método común para todos los animales
        public void Comer()
        {
            Console.WriteLine($"{Nombre} está comiendo.");
        }
    }

    //Clase derivada que representa un perro
    public class Perro : Animal
    {
        //Constructor(de la clase derivada) que llama al constructor base(o sea, al constructor de la clase animal)
        public Perro(string nombre) : base(nombre)
        {
        }

        //Implementación del método abstracto HacerSonido
        public override void HacerSonido()
        {
            Console.WriteLine($"{Nombre} dice: Guau Guau!");
        }
    }

    //Clase derivada que representa un gato
    public class Gato : Animal
    {
        //Constructor(de la clase derivada) que llama al constructor base(o sea, al constructor de la clase animal)
        public Gato(string nombre) : base(nombre)
        {
        }

        //Implementación del método abstracto HacerSonido
        public override void HacerSonido()
        {
            Console.WriteLine($"{Nombre} dice: Miau Miau!");
        }
    }

    public class Program //Define la clase Program que contiene el punto de entrada de la aplicación (metodo main)
    {
        static void Main(string[] args)
        {
            //Crear una instancia de Perro y llama a sus métodos
            Animal perro = new Perro("Bruno");
            perro.HacerSonido();  // Salida: Bruno dice: Guau Guau!
            perro.Comer();        // Salida: Bruno está comiendo.

            //Crear una instancia de Gato y llama a sus métodos
            Animal gato = new Gato("Tom");
            gato.HacerSonido();   // Salida: Tom dice: Miau Miau!
            gato.Comer();         // Salida: Tom está comiendo.

            //Mantiene la consola abierta
            //esperando que el usuario de enter para cerrarla
            Console.ReadLine();
        }
    }
}
