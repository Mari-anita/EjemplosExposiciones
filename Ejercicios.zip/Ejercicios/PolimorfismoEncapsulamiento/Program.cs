﻿// See https://aka.ms/new-console-template for more information
using System;

namespace PolimorfismoEncapsulamiento
{
    //Clase base
    public class Animal
    {
        //Campo privado
        private string nombre;

        //Propiedad pública para acceder al campo privado
        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        //Método virtual que puede ser sobreescrito en las clases derivadas
        public virtual void HacerSonido()
        {
            Console.WriteLine("El animal hace un sonido.");
        }
    }

    //Clase derivada
    public class Perro : Animal
    {
        //Sobreescribiendo el método HacerSonido
        public override void HacerSonido()
        {
            Console.WriteLine("Y ladra.");
        }
    }

    //Clase derivada
    public class Gato : Animal
    {
        //Sobreescribiendo el método HacerSonido
        public override void HacerSonido()
        {
            Console.WriteLine("Y maúlla.");
        }
    }

    public class Program
    {
        static void Main()
        {
            //Creando objetos de las clases derivadas
            Animal miPerro = new Perro();
            Animal miGato = new Gato();

            //Usando la propiedad y el método polimórfico
            miPerro.Nombre = "Bruno";
            miGato.Nombre = "Tom";

            Console.WriteLine($"El perro se llama: {miPerro.Nombre}");
            miPerro.HacerSonido();

            Console.WriteLine($"El gato se llama: {miGato.Nombre}");
            miGato.HacerSonido();
        }
    }
}

